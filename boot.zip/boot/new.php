
<!DOCTYPE html>

<!--[if gt IE 8]><!--> <html lang="en" class="no-js"> <!--<![endif]-->
    <head>
    	<!-- meta character set -->
        <meta charset="utf-8">
		<!-- Always force latest IE rendering engine or request Chrome Frame -->
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title>Carport</title>		
		<!-- Meta Description -->
        <meta name="description" content="Find suitable car for you">
        <meta name="keywords" content="cars, search, sedan, suv">
        <meta name="author" content="Shebin John and Team">
		
		<!-- Mobile Specific Meta -->
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
		<!-- CSS
		================================================== -->
		
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
		
		<!-- Fontawesome Icon font -->
        <link rel="stylesheet" href="css/font-awesome.min.css">
		<!-- bootstrap.min -->
        <link rel="stylesheet" href="css/jquery.fancybox.css">
		<!-- bootstrap.min -->
        <link rel="stylesheet" href="css/bootstrap.min.css">
		<!-- bootstrap.min -->
        <link rel="stylesheet" href="css/owl.carousel.css">
		<!-- bootstrap.min -->
        <link rel="stylesheet" href="css/slit-slider.css">
		<!-- bootstrap.min -->
        <link rel="stylesheet" href="css/animate.css">
		<!-- Main Stylesheet -->
        <link rel="stylesheet" href="css/main.css">
        <!--For grid -->
        
        <link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
		<!-- Modernizer Script for old Browsers -->
        <script src="js/modernizr-2.6.2.min.js"></script>

    </head>
	
    <body id="body">

		<!-- preloader -->
		<div id="preloader">
            <div class="loder-box">
            	<div class="battery"></div>
            </div>
		</div>
		<!-- end preloader -->

        <!--
        Fixed Navigation
        ==================================== -->
        <header id="navigation" class="navbar-inverse navbar-fixed-top animated-header">
            <div class="container">
                <div class="navbar-header">
                    <!-- responsive nav button -->
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
                    </button>
					<!-- /responsive nav button -->
					
					<!-- logo -->
					<h1 class="navbar-brand">
						<a href="#body">CarPort</a>
					</h1>
					<!-- /logo -->
                </div>

				<!-- main nav -->
                <nav class="collapse navbar-collapse navbar-right" role="navigation">
                    <ul id="nav" class="nav navbar-nav">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="new.php">New</a></li>
                         <li><a href="about.php">About</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        
                    </ul>
                </nav>
				<!-- /main nav -->
				
            </div>
        </header>
        <!--
        End Fixed Navigation
        ==================================== -->
		
		<main class="site-content" role="main">
		
        <!--
        Home Slider
        ==================================== -->
         <br><br><br>   
                    
                    <!--Grid-->
             <div class="banner-top">
			<div class="header-bottom">
				 <div class="header_bottom_right_images">
				     	<div class="content-wrapper">		  
						<div class="content-top">
                        
							 <div class="about_wrapper"><h1>Specials</h1>
				             </div>
                                
							  <div class="text">
								<div class="grid_1_of_3 images_1_of_3">
                                <!-- Grid image -->
									<div class="grid_1">
										<img src="img/car/BMW_3_Series.jpg"  alt="BMW" height="250" width="500">
											
                                            <div class="grid_desc">
												<p id="model" class="title">Model : 3 Series</p>
                                                <p id="maker" class="title">Maker : BMW</p>
                                                <p id="fuel" class="title">Fuel : Petrol</p>
                                                <p id="transmission" class="title">Transmission : Auomatic</p>
                                                <p id="year" class="title">Year : 2015</p>
													 <div class="price" style="height: 19px;">
													 	 <span class="reducedfrom">Rs. 40.00 lakhs</span>
								        				
													 </div>
													 
											</div>
								 </div>
                                 <div class="clear">
                                 </div>
							 </div>
                              
                              <!-- next Grid image -->
                              <div class="text">
									<div class="grid_1_of_3 images_1_of_3">
                                
									<div class="grid_1">
										<img src="img/car/benz_c_class.jpg"  alt="benz" height="250" width="500">
											
                                            <div class="grid_desc">
												<p id="model" class="title">Model : C Class</p>
                                                <p id="maker" class="title">Maker : Benz</p>
                                                <p id="fuel" class="title">Fuel : Petrol</p>
                                                <p id="transmission" class="title">Transmission : Auomatic</p>
                                                <p id="year" class="title">Year : 2014</p>
													 <div class="price" style="height: 19px;">
													 	 <span class="reducedfrom">Rs. 45.00 lakhs</span>
								        				
													 </div>
													 
											</div>
								 </div>
                                 <div class="clear">
                                 </div>
                                </div>
                                
                                <div class="text">
									<div class="grid_1_of_3 images_1_of_3">
                               
									<div class="grid_1">
										<img src="img/car/jaguar_xf.jpg" height="250" width="500" alt="">
											
                                            <div class="grid_desc">
												<p id="model" class="title">Model : XF</p>
                                                <p id="maker" class="title">Maker : Jaguar</p>
                                                <p id="fuel" class="title">Fuel : Petrol</p>
                                                <p id="transmission" class="title">Transmission : Auomatic</p>
                                                <p id="year" class="title">Year : 2015</p>
													 <div class="price" style="height: 19px;">
													 	 <span class="reducedfrom">Rs. 50.00 lakhs</span>
								        				
													 </div>
													 
											</div>
								  </div>
                                  <div class="clear">
                                  </div>
                                 </div>
								
                                <div class="text">
									<div class="grid_1_of_3 images_1_of_3">
                                <!-- Grid image 1st row 1st image -->
									<div class="grid_1">
										<img src="img/car/Maruthi_swift.jpg" height="250" width="500" alt="">
											
                                            <div class="grid_desc">
												<p id="model" class="title">Model : Swift</p>
                                                <p id="maker" class="title">Maker : Maruthi</p>
                                                <p id="fuel" class="title">Fuel : Diesel</p>
                                                <p id="transmission" class="title">Transmission : Manual</p>
                                                <p id="year" class="title">Year : 2014</p>
													 <div class="price" style="height: 19px;">
													 	 <span class="reducedfrom">Rs. 4.50 lakhs</span>
								        				
													 </div>
													 
											</div>
								  </div>
                                  <div class="clear">
                                  </div>
                                </div>
                                
                                <div class="text">
								  <div class="grid_1_of_3 images_1_of_3">
                               
									<div class="grid_1">
										<img src="img/car/Audi_A4.jpg" height="250" width="500" alt="">
											
                                            <div class="grid_desc">
												<p id="model" class="title">Model : A4</p>
                                                <p id="maker" class="title">Maker : Audi</p>
                                                <p id="fuel" class="title">Fuel : Petrol</p>
                                                <p id="transmission" class="title">Transmission : Auomatic</p>
                                                <p id="year" class="title">Year : 2016</p>
													 <div class="price" style="height: 19px;">
													 	 <span class="reducedfrom">Rs. 38.00 lakhs</span>
								        				
													 </div>
													 
											</div>
								   </div>
                                   <div class="clear">
                                    </div>
                                </div>
                          </div><!--content-top -->
                     </div><!--content-wrapper -->
                   </div><!--header_bottom_right_images -->
                </div><!--header-top -->
          </div><!--banner-top -->
                    
			
			
			
		
		</main>
		
		<footer id="footer">
			<div class="container">
				
						<br><br><br>
						
						<p style="text-align:center;">Copyright 2016 Design and Developed By Carport</p>
				
			</div>
		</footer>
		
		<!-- Essential jQuery Plugins
		================================================== -->
		<!-- Main jQuery -->
        <script src="js/jquery-1.11.1.min.js"></script>
		<!-- Twitter Bootstrap -->
        <script src="js/bootstrap.min.js"></script>
	
		<!-- jquery.fancybox.pack -->
        <script src="js/jquery.fancybox.pack.js"></script>
		<!-- Google Map API -->
		<script src="http://maps.google.com/maps/api/js?sensor=false"></script>
		<!-- Owl Carousel -->
        <script src="js/owl.carousel.min.js"></script>
        <!-- jquery easing -->
        <script src="js/jquery.easing.min.js"></script>
        <!-- Fullscreen slider -->
        <script src="js/jquery.slitslider.js"></script>
        <script src="js/jquery.ba-cond.min.js"></script>
		<!-- onscroll animation -->
        <script src="js/wow.min.js"></script>
		<!-- Custom Functions -->
        <script src="js/main.js"></script>
    </body>
</html>